<?php
/*

Matt's MySQL Panel - administer MySQL databases remotely
Copyright (C) 2001 Matt Wilson <matt@mattsscripts.co.uk

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

// the english language file
define(_WELCOME_, "Por favor entre o nome do usu�rio e senha. Informe tamb�m o nome do banco de dados que voc� deseja acessar, se nenhum banco for informado uma lista ser� exibida com todos os bancos dispon�veis. Para conectar a um HOST remoto voc� deve informar o endere�o do HOST na caixa \"Server Host\". Se um error ocorrer � prov�vel que seja algo como usu�rio ou senha incorreta.");
define(_USERNAME_, "Usu�rio");
define(_PASSWORD_, "Senha");
define(_DBNAME_, "Nome do Banco");
define(_DBHOST_, "HOST Servidor");
define(_LOGIN_, "Login");
define(_USE_, "Usar");

// about/info page
define(_ABOUT_, "Sobre");
define(_ABOUTINFO_, "\"Matt's MySQL Control Panel\" (MPanel) foi escrito por Matt Wilson para permitir o acesso ao MySQL via browser ao inv�s de telnet ou terminal, uma alternativa para as pessoas que desejam usar o MySQL mas n�o querem ter problemas com comandos em modo texto, usando este script voc� poder�:");
define(_CREATETABLEINFO_, "Criar tabelas com todas as funcionalidades do MySQL");
define(_DELETETABLEINFO_, "Apagar tabelas de um banco de dados");
define(_OPTIMIZETABLEINFO_, "Otimizar tabelas para melhorar a velocidade");
define(_RENAMETABLEINFO_, "Renomear tabelas");
define(_ADDFIELDSINFO_, "Adicionar campos para tabela existente");
define(_EDITFIELDINFO_, "Editar atributos do campo em tabelas existentes e/ou em campos");
define(_DELETEDBINFO_, "Apagar banco de dados");
define(_IMPORTINFO_, "Importar banco de dados do seu MySQL local");
define(_EXPORTDBINFO_, "Exportar banco de dados do servidor");
define(_EXPORTTABLEINFO_, "Exportar tabelas individuais do servidor");
define(_EXECUTESQLINFO_, "Executa uma query SQL neste servidor");
define(_CONTACT_, "Contato");
define(_CONTACTINFO_, "Para falar comigo sobre qualquer quest�o, mande email para <a href=\"mailto: matt@mattsscripts.co.uk\">matt@mattsscripts.co.uk</a> e eu vou responder o mais breve poss�vel.");
define(_BACKTOLOGINPAGE_, "Voltar para a p�gina de login");
define(_BACKTOMAINPAGE_, "Voltar para a p�gina principal");
define(_BACK_, "Voltar");

define(_CREATETABLEERROR_, "Houve um erro ao tentar criar uma nova tabela");
define(_CREATETABLEGOOD_, "Tabela criada com sucesso");
define(_ADDNEWFIELD_, "Adicionar novo campo");
define(_ADDFIELDINFO_, "Para poder criar um novo campo na sua taela voc� deve fornecer o nome do campo e o tipo de campo, isto pode ser informado abaixo");
define(_FIELDNAME_, "Nome do Campo");
define(_FIELDTYPE_, "Tipo do Campo");
define(_VALUE_, "Valor");
define(_FUNC_, "Func.");

define(_TINYINT_, "Tiny integer");
define(_SMALLINT_, "Small integer");
define(_MEDIUMINT_, "Medium integer");
define(_INT_, "Integer");
define(_BIGINT_, "Big integer");
define(_FLOAT_, "Float");
define(_DOUBLE_, "Double");
define(_DECIMAL_, "Decimal");
define(_CHAR_, "Char");
define(_VARCHAR_, "Varchar");
define(_TINYTEXT_, "Tiny text");
define(_TINYBLOB_, "Tiny blob");
define(_ENUM_, "Enum");
define(_TEXT_, "Text");
define(_BLOB_, "Blob");
define(_MEDIUMTEXT_, "Medium text");
define(_MEDIUMBLOB_, "Medium blob");
define(_LONGTEXT_, "Long text");
define(_LONGBLOB_, "Long blob");
define(_DATETIME_, "Date &amp; Time");
define(_DATE_, "Date");
define(_TIME_, "Time");
define(_YEAR_, "Year");
define(_TIMESTAMP_, "Timestamp");

define(_MODIFIERS_, "Modificadores");
define(_OK_, "OK");

define(_CREATEKEYERROR_, "Houve um erro ao tentar criar uma nova Chave");
define(_CREATEKEYGOOD_, "Chave criada com sucesso");
define(_ADDKEY_, "Adicionar nova chave");
define(_ADDKEYTOTABLE_, "Adicionar nova chave para a tabela");
define(_ADDKEYINFO_, "Para criar uma nova chave, voce precisa entrar alguns detalhes abaixo, o nome da Chave, o tipo de Chave e campos que a chave vai cobrir.");
define(_ADDKEYWARNING_, "<u>NOTA:</u>Lembre-se uma chave n�o pode exceder 255 caracteres no total!");
define(_KEYNAME_, "Nome da chave");
define(_KEYTYPE_, "Tipo da chave");
define(_PRIMARYKEY_, "Primary key");
define(_UNIQUEKEY_, "Unique key");
define(_NORMALKEY_, "Key");
define(_KEYFIELDS_, "Campos a cobrir");
define(_FIELDS_, "Campos");

define(_ADDRECORDERROR_, "Impossivel adicionar registro");
define(_ADDRECORDGOOD_, "Registro adicionado a tabela");
define(_LISTFIELDSERROR_, "Impossivel recuperar lista de campos");
define(_ADDRECORD_, "Adicionar um registro");

define(_EXPORTTABLE_, "Exportar tabela");
define(_EXECUTESQL_, "Executar comando SQL");

define(_CREATETABLE_, "Criar nova tabela");
define(_CREATETABLEINFO_, "Para criar uma nova tabela, simplesmente entre o nome da nova tabela que voc� deseja criar. A tabela ser� criada com um campo vazio chamado \"delete_me\", isto � porque todas as tabelas requerem que ao menos um capo para poderem ser criadas.");
define(_NEWTABLENAME_, "Nome da nova tabela");
define(_DELETEDBERROR_, "Imposs�vel apagar o banco de dados");
define(_DROPFIELDERROR_, "Imposs�vel remover o campo");
define(_DROPFIELDGOOD_, "Campo removido");
define(_DROPKEYERROR_, "Impossivel remover a chave");
define(_DROPKEYGOOD_, "Chave apagada");
define(_DELETERECORDERROR_, "Erro ao apagar o registro");
define(_DELETERECORDGOOD_, "Registro apagado");
define(_DROPTABLEERROR_, "Impossivel apagar a tabela");
define(_DROPTABLEGOOD_, "Tabela apagada");
define(_CHOOSEEXPORT_, "Escolha os itens para exportar");
define(_EXPORTINGDATA_, "Exportando dados");
define(_CONSTRUCTION_, "Constru��o");
define(_TABLEDATA_, "Dados da Tabela");
define(_TABLEKEYS_, "Chaves da Tabela");
define(_EDITFIELDERROR_, "Impossivel editar o tipo do campo");
define(_EDITFIELDGOOD_, "Tipo do campo alterado");
define(_EDITFIELD_, "Alterar o tipo do campo");
define(_NEWFIELDTYPE_, "Novo tipo de campo");

define(_ERROR_, "Um erro ocorreu");
define(_ERRORINFO_, "Desculpe, mas ocorreu um erro quanto voc� tentou realizar esta tarefa, se n�o era isso que voc� esperava e parece um BUG, por favor informe o erro escrevendo um e-mail para <a href=\"mailto: bugs@mattsscripts.co.uk\">este</a> endere�o, informando como, quando e porque e eu tentarei consertar o programa.");
define(_ERRORMSG_, "Mensagem de erro");

define(_FINDDB_, "Localizar banco de dados");
define(_ERRORDBCONNECT_, "Imposs�vel de conectar com o servidor de banco de dados, por favor verifique o usu�rio e senha.");
define(_ERRORDBLIST_, "Imposs�vel de obter a lista de bancos de dados presente no servidor, por favor solicite ajuda ao administrador.");
define(_SELECTDB_, "Por favor selecione o banco de dados que voc� deseja administrar");
define(_DBLISTINFO_, "Logo abaixo � a lista de todos os bancos de dados existentes no servidor informado. Por favor clique no banco de dados que voc� deseja administrar.");

define(_HELPPAGE_, "P�gina de Ajuda");
define(_HELPINTRO_, "\"Matt's MySQL Control-Panel\" foi desenvolvido para que as pessoas possam acessar bancos de dados MySQL, construir tabelas etc. sem precisar uma conta de telnet. Uma s�rie de coisas podem ser feitas com este script, incluindo;");
define(_HELPCREATEDELETETABLE_, "Criando/Apagando tabela");
define(_HELPDELETEDB_, "Apagando banco de dados");
define(_INTRO_, "Introdu��o");
define(_HELPADDDELETEFIELDS_, "Adicionando/Apagando campos das tabelas");
define(_HELPALTERFIELDS_, "  Altera��o de nomes de campo e tipos");
define(_HELPINSERTRECORDS_, "Inserindo registros nas tabelas");
define(_HELPDELETERECORDS_, "Apagando registros em tabelas");
define(_HELPMODIFYRECORDS_, "Modificando registros existentes em tabelas");
define(_HELPEXECUTESQL_, "Executar comandos MySQL");

define(_ETC_, "etc");

define(_HELPTOC_, "Tabela de Conte�do");
define(_HELPLOGIN_, "Fazendo login no sistema");
define(_HELPCREATETABLE_, "Criando uma tabela");
define(_HELPADDFIELD_, "Adicionando um campo a uma tabela");
define(_HELPEDITFIELD_, "Editando o tipo do campo");
define(_HELPINSERTRECORD_, "Inserindo um registro na tabela");
define(_HELPQUERYTABLE_, "Fazento uma query na tabela");
define(_HELPDELETEMODIFYRECORD_, "Apagando/Editando um registro na tabela");
define(_HELPDELETEFIELD_, "Apagando um campo na tabela");
define(_HELPDELETETABLE_, "Apagando uma tabela do banco de dados");
define(_HELPDELETEDB_, "Apagando um banco de dados");
define(_HELPEXECUTINGSQL_, "Executando um comando MySQL");
define(_HELPEXPORTING_, "Exportando uma tabela ou banco de dados");
define(_HELPIMPORTING_, "Importanto seu banco de dados");


define(_HELPLOGININFO_, "OK, esta � a parte mais importante, voc� precisa fazer tudo correto, caso contr�rio nada vai funcionar! O nome do usu�rio (username) � o nome usado para conectar no banco de dados MySQL e a senha (password) � usada para obter acesso ao banco de dados.  A pr�xima parte � o nome do banco que voc� deseja usar, se voc� deixar este campo em branco,  uma lista com todos os bancos dispon�veis ser� exibida para voc� escolher. A �ltima parte � o servidor do banco de dados MySQL, isto � muito importante e alguns servidores n�o permitem conex�es remotas, neste caso qualquer script que acesse o banco dever� estar rodando no mesmo servidor do banco.");
define(_HELPCREATETABLEINFO_, "Criar uma tabela � muito f�cil com este script, depois de logado clique em \"Criar Tabela\" no bot�o ao lado esquerdo na lateral da tela, isto deve abrir uma nova janela exibindo uma caixa de entrada e um bot�o \"Criar\", basta informar o nome da tabela que voc� deseja criar e clicar em \"Criar\". Depois disto basta dar um refresh no browser e a nova tabela estar� criada! A nova tabela vai conter um campo chamado \"Delete_me\" isto � porque tabelas novas <b>precisam</b> conter pelo menos um campo, isto significa que basta voc� incluir os campos desejados e apagar este tempor�rio, para informa��es de como fazer isto, clique <a href=\"help.html#delfield\">aqui</a>.");
define(_HELPADDFIELDINFO_, "Quando voc� desejar adicionar um novo campo ao seu banco de dados, voc� deve selecionar a tabela, isto ir� mostrar a lista de todos os campos daquela tabela. Para adicionar um novo campo basta clicar em \"Adicionar Campo\" na lateral da tela, vai aparecer um popup perguntando o nome e o tipo do campo a ser adicionado, por favor note que o tipo de campo � importate, se voc� n�o est� familiarizado com os diferentes tipos de campo do MySQL, eu recomendo voc� ler uma documenta��o a respeito no <a target=_new href=\"http://www.mysql.com/documentation/index.html\">Manual Oficial do MySQL</a> ou em <a href=\"http://www.your-name-here.co.uk/mysql/fields.html\" target=_new>nesta p�gina</a> que cont�m algumas informa��es sobre campos, tamanhos e tipos.");
define(_HELPEDITFIELDINFO_, "Editar informa��es do campo e configurar o tipo do campo � outro processo que requer conhecimentos sobre o MySQL e tipos (veja '3. Adicionando um campo na tabela' para ajuda) e precisa ser feito com informa��es sobre a tabela, isto voc� acha clicando na tabela, que cont�m o campo que voc� deseja alterar. Pr�ximo a cada campo existe um grupo de bot�es, um destes � o \"Editar tipo\", clicando neste bot�o uma nova janela ir� abrir com espa�o para voce entrar o novo tipo, com isto informado, basta confirmar e o banco de dados estar� atualizado.");
define(_HELPINSERTRECORDINFO_, "Para inserir um registro em uma das tabelas, voc� precisa seleciona-la primeiro na tela principal, quando ent�o ser� exibida uma p�gina contendo todos os campos da tabela e informa��es sobre os tipos dos campos. Clicando no bot�o \"Adicionar Registro\" ser� exibida uma nova p�gina contendo campos de entrada para cada campo da tabela. Depois de preencher as informa��es clique em \"Adicionar Registro\" para inserir o novo registro na tabela.");
@@define(_HELPQUERYTABLEINFO_, "Isto � simples de se fazer, uma vez selecionada a tabela que cont�m os dados que voc� deseja, basta clicar em \"Query Tabela\" no cando esquerdo da tela, e isto trar� algumas caixas de texto - uma para cada campo na sua tabela. Coloque o testo que voc� deseja pesquisar no campo correspondente, e o script vai procurar no banco de dados atual e nas tabelas por registros que satisfa�am os crit�rios da query, e ir� mostrar os resultados.");
@@define(_HELPDELETEMODIFYRECORDINFO_, "Este recurso � f�cil de usar, entretanto pode ser perigoso se voc� tiver registros m�ltiplos id�nticos. O problema � que se voc� tem dois registros id�nticos, e deletar um deles, automaticamnte o outro ser� deletado - para evitar isso utilize campos com ID e campos com chave �nica (Primary Keys). Estes campos s�o usados para distinguir os registros. Para apagar um registro, primeiro clique na tabela onde cont�m o campo e depois que no bot�o 'Apagar Registro' na lateral da tela, ent�o preencha as informa��es necess�rias e ent�o clique em PESQUISAR, os resultados ser�o exbidos na tela, simplesmente clique em \"Apagar\" para remover o registro da tabela. Modificar um campo � feito da mesma maneira, a �nica diferen�a � que voc� clica em \"Modificar\" ap�s uma pesquisa e informar os detalhes para gravar na tabela.");
define(_HELPDELETEFIELDINFO_, "Deletar um campo em uma das tabelas � mais facil do que adicionar, simplesmente selecione a tabela na tela principal e clique no bot�o APAGAR pr�ximo ao campo desejado, o script ir� perguntar tres vezes se voc� deseja apagar o campo, e logo ap�s a confirma��o o campo e as informa��es ser�o apagadas.");
define(_HELPDELETETABLEINFO_, "Deletar uma tabela do banco de dados � mais f�cil que deletar um campo das tabelas, simplesmente clique no bot�o APAGAR que est� pr�ximo da tabela desejada e confirme sua escolha, mas lembre-se que ap�s apagar uma tabela, esta n�o tem como ser recuperada, nem os dados que estiverem dentro.");
define(_HELPDELETEDBINFO_, "Para apagar um banco de dados, clique em \"Apagar Banco de Dados\" na tela principal, novamente voc� ser� perguntado tr�s vezes para confirmar o banco de dados que ser� apagado, juntamente com todas as tabelas e informa��es. ");
define(_HELPEXECUTINGSQLINFO_, "Para poder executar um comando no MySQL, � claro que voc� precisa saber qual o o comando a executar e no que ele vai afetar o seu banco de dados. Se voc� sabe usar o MySQL simplesmente entre com o comando na caixa de di�logo, na tela principal, se n�o obtiver nenhuma mensagem de erro � porque o comando foi executado perfeitamente.");
define(_HELPEXPORTINGINFO_, "Esta fun��o do script server para voc� obter uma c�pia do banco de dados, isto permite a voc� gerar um DUMP do banco de dados de forma a poder exportar os dados e tabelas para outro servidor MySQL, ou somente para fazer um backup.");
define(_HELPIMPORTINGINFO_, "Importar o seu banco de dados criado pele MYSQLDUMP � muito f�cil de fazer.  Para fazer isto, clique em \"Importar Dados\" na tela principal, isto abrir� uma janela para voc� informar o arquivo local com os dados, este � o arquivo que voc� precisa fazer upload, ent�o clique em  \"Importar!\" para importar os dados para o banco de dados, aguarde e d� um refresh na tela para ver os dados importados.");

define(_IMPORTDATA_, "Importando Dados");
define(_IMPORTDATAINSTRUCT_, "Para importar dados para este banco voce precisa clicar em \"Browse...\" e selecionar um arquivo de dump. Estes arquivos s�o apenas uma longa lista de comandos SQL que v�o reconstruir o banco de dados.");
define(_IMPORTFILE_, "Importanto Arquivo");
define(_IMPORTDBDATA_, "Importando dados do banco");

define(_WELCOMETITLE_, "Bem-Vindo");
define(_EXPORTDB_, "Exportanto Banco de Dados");
define(_DELETEDB_, "Apagando banco de dados");
define(_DELETETABLE_, "Apagando tabela");
define(_OPTIMIZETABLE_, "Otimizando tabela");
define(_DELETEFIELD_, "Apagando campo");
define(_DELETEDBCONFIRM_, "Voc� tem certeza que quer apagar este banco de dados?");
define(_DELETEFIELDCONFIRM_, "Voc� tem certeza que quer apagar este campo?");
define(_DELETETABLECONFIRM_, "Voc� tem certeza que quer apagar esta tabela?");
define(_LOGOUTCONFIRM_, "OK para o logout?");
define(_LOGOUT_, "Logout");
define(_TABLENAME_, "Nome da Tabela");
define(_COMMANDS_, "Comandos");
define(_KEYMANAGEMENT_, "Gerenciamento de Chaves");

define(_DELETEKEYCONFIRM_, "Voc� tem certeza que quer apagar esta chave?");
define(_DELETEKEY_, "Apagar Chave");
define(_MODIFYARECORD_, "Modificar um registro");

define(_LOGINERROR_, "Imposs�vel de fazer o login");
define(_LOGINERRORINFO_, "Desculpe, mas n�o � poss�vel fazer o seu login no MySQL, isto pode ocorrer por diversas raz�es, verifique se o seu usu�rio e senha est�o corretos ou se o banco de dados existe no servidor. O erro tamb�m pode ocorrer devido ao servidor n�o permitir conex�es remotas, caso voc� esteja conectando remotamente. Se o problema persistir voc� deve entrar em contato com o administrador do servidor ou do banco de dados.");

define(_SEARCHRESULTS_, "Resultados da Pesquisa");
define(_FOUNDRECORDS_, "Os seguintes registros foram localizados");
define(_NOPRIMARYKEY_, "Nenhuma chave prim�ria ou chave �nica est� presente nesta tabela, portanto qualquer tentativa de apagar ou modificar um registro pode trazer resultados imprevis�veis !");
define(_DELETERECORDCONFIRM_, "OK para apagar este registro?");
define(_DELETERECORD_, "Apagar registro");
define(_MODIFYRECORD_, "Modificar registro");
define(_SEARCHEMPTY_, "Nenhum registro foi localizado usando a sua pesquisa");
define(_RENAMEFIELD_, "Renomear campo");
define(_FIELDNEWNAME_, "Novo nome para o campo");
define(_FIELDNEWNAMEINFO_, "Por favor entre o novo nome para o campo e pressione 'OK'.");

define(_RENAMETABLE_, "Renomear tabela");
define(_TABLENEWNAME_, "Novo nome para a tabela");
define(_TABLENEWNAMEINFO_, "Por favor entre o novo nome para a tabela e pressione 'OK'");
define(_SQLRESULTS_, "Resultados SQL");
define(_SQLEXECUTED_, "Comando SQL executado com sucesso");
define(_SQLOUTPUT_, "Aqui est� o resultado do seu comando SQL");
define(_SQLERROR_, "Imposs�vel de executar o comando SQL");

define(_SQLRESULTCODE_, "Query executada, MySQL retornou o seguinte");
define(_SQLRESULTROWS_, "N�mero de linhas retornados");
define(_SQLRESULTROWSAFFECTED_, "N�mero de linhas retornadas");
define(_SQLRESULTFIELDS_, "N�mero de campos retornados");
define(_TABLEDETAILS_, "Detalhes da Tabela");
define(_ADDNEWFIELD_, "Adicionar novo campo");
define(_SEARCHDELETEMODIFYRECORDS_, "Pesquisar/Apagar/Modificar registros");

define(_CURDATABASE_, "Banco de dados atual");
define(_CURTABLE_, "Tabela atual");
define(_CHANGEFIELDTYPE_, "Mudando o tipo do campo");
define(_SUCCESSMOD_, "Modificado com sucesso");
define(_ERRORMOD_, "Erro na modifica��o");
define(_ERRORMODRECORD_, "Erro ao encontrar para modifica��o");
define(_ERROROPTIMIZE_, "Erro ao otimizar tabela");
define(_SUCCESSOPTIMIZE_, "Tabela otimizada com sucesso");
define(_ERRORTABLEDESC_, "Imposs�vel de obter a descri��o da tabela");
define(_SEARCHRECORDS_, "Pesquisar registros");
define(_OPERATION_, "Opera��o");
define(_TYPE_, "Tipo");
define(_ERRORENAMEFIELD_, "Imposs�vel de renomear o campo");
define(_SUCCESSRENAMEFIELD_, "O campo foi renomeado com sucesso");
define(_ERRORRENAMETABLE_, "Imposs�vel de renomear tabela");
define(_SUCCESSRENAMETABLE_, "Tabela renomeada com sucesso");
define(_RESET_, "Reset");

define(_AUTO_INCREMENT_FM_, "Auto Increment (Todos os tipos inteiros)");
define(_BINARY_FM_, "Binary (Char, Varchar)");
define(_NOT_NULL_FM_, "Not NULL (Todos os tipos)");
define(_UNSIGNED_FM_, "Unsigned (Tipos num�ricos)");
define(_ZERO_FILL_FM_, "Zero Fill (Tipos num�ricos)");
define(_DEFAULT_FM_, "Default (Todos, exceto BLOB, TEXT)");
define(_MODIFIERS_, "Modificadores");

define(_IMPORTSUCCESS_, "Dados importados com suecesso, n�mero de querys SQL executadas");

define(_UPDATE_, "Atualizar");
define(_BROWSE_, "Browse");
define(_EXPORTFMT_, "Exportar Formato");
define(_CHANGEDB_, "Mudar Banco de Dados");
define(_CHANGETABLE_, "Mudar Tabela");

define(_SHOWPAGE_, "Mostrar n�mero da p�gina");
define(_RESULTSPERPAGE_, "N�mero de resultados por p�gina");
define(_NEXTPAGE_, "Pr�xima P�gina");
define(_PREVIOUSPAGE_, "P�gina Anterior");
define(_NOTE_, "Nota");


define(_ADDFIELDAFTER_, "Adicionar campo ap�s");
define(_TABLEEND_, "Fim da tabela");

define(_FINDDB_, "Localizar banco de dados");

define(_DBMANAGER_, "Gerenciador do Banco de Dados");
define(_ALLOWEDDBS_, "Seu usu�rio tem acesso aos seguintes bancos de dados e respectivas tabelas");
define(_DISALLOWEDDBS_, "Estes s�o os bancos de dados que voc� n�o tem acesso");
define(_WELCOMEDB_, "Bem-vindo a p�gina de administra��o do banco de dados. Voc� pode selecionar um banco de dados para gerenciar, ou escolher um abaixo (se tiver permiss�o de acesso).");
define(_CREATEDB_, "Criar um banco de dados");
define(_CREATEDBERROR_, "Impossivel de criar um banco de dados");
define(_CREATEDBGOOD_, "Banco de dados criado com sucesso");
define(_DELETEDBERROR_, "Imposs�vel apagar o banco de dados");
define(_DELETEDBGOOD_, "Banco de dados apagado com sucesso");
define(_GRANTDBERROR_, "Impossivel de dar permiss�es ao usu�rio");
define(_GRANTDBGOOD_, "Permiss�es efetuadas com sucesso");

define(_GRANTUSER_, "Permiss�es de acesso ao usu�rio");

define(_IMPORTTYPE_, "Formato de importa��o do arquivo");
define(_CSVHEADER_, "arquivo CSV cont�m field header line");
define(_CSVCONTAINER_, "campo CSV do container");
define(_CSVSEPERATOR_, "campo CSV do seperator");




?>
