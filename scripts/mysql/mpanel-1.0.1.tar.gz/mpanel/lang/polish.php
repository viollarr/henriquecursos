<?php
/*

Matt's MySQL Panel - administer MySQL databases remotely
Copyright (C) 2001 Matt Wilson <matt@mattsscripts.co.uk

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

// the english language file

/*
Translation into Polish of the MySQL Panel from Matt Wilson by:
             WWW.GWARANT.NET your internet provider
             admin@gwarant.net for further questions
*/

define(_WELCOME_, "Prosze wpisz swoj login i has�o ponizej. wpisz takze nazwe bazy do ktorej chcesz wejsc, Jezeli nie wybierzesz bazy danych pojawi sie lista baz z ktorej bedziesz sobie mogl wybrac baze.");
define(_USERNAME_, "Login");
define(_PASSWORD_, "Has�o");
define(_DBNAME_, "Nazwa bazy");
define(_DBHOST_, "Host serwera");
define(_LOGIN_, "Login");
define(_USE_, "Uzyteczno��");

// about/info page
define(_ABOUT_, "O programie");
define(_ABOUTINFO_, "\"Panel kontrlony Matta Willsona\" (MPanel) zostal napisany przez Matta Wilsona aby umozliwic uzytkownikom obslug� bazy mysqla poprzez przegladarke www zamiast polaczenia via telnet, lecz tak�e dla ludzi ktorzy pragneliby obslugiwac baze danych lecz nie znaja odpowiednich komend.Uzywaj�c tego panelu administracyjnego nastepujace rzeczy mog� zostac osi�gniete:");
define(_CREATETABLEINFO_, "Tworzy tabele w bazie mysqla");
define(_DELETETABLEINFO_, "Usuwa table w bazie mysqla");
define(_OPTIMIZETABLEINFO_, "Optymalizuje bazy i zwieksza szybkosc operacyjn�");
define(_RENAMETABLEINFO_, "Zmienia nazwy tabel");
define(_ADDFIELDSINFO_, "dodaje pola do bazy");
define(_EDITFIELDINFO_, "Edytuje atrybuty p�l w bazie");
define(_DELETEDBINFO_, "Usuwa bazy danych");
define(_IMPORTINFO_, "Imporuje bazy danych z twojego localnego serwera Mysql");
define(_EXPORTDBINFO_, "Exportuje bazy z serwera");
define(_EXPORTTABLEINFO_, "Exportuje indywidualne tabele z bazy");
define(_EXECUTESQLINFO_, "Wykonuje manualne operacje an serwerze");define(_CONTACT_, "Kontakt");
define(_CONTACTINFO_, "Aby sie ze mn� skontaktowa� aby na przyk�ad zada� pytanie. mailujce mnie <a href=\"mailto: matt@mattsscripts.co.uk\">matt@mattsscripts.co.uk</a> i postaram sie jak najszybciej odpowiedziec.");
define(_BACKTOLOGINPAGE_, "Powr�t do strony logowania");
define(_BACKTOMAINPAGE_, "Powr�t do strony g�ownej");
define(_BACK_, "Powr�t");

define(_CREATETABLEERROR_, "Wyst�pil b��d podczas tworzenia bazy");
define(_CREATETABLEGOOD_, "Tabela utworzona pomy�lnie");
define(_ADDNEWFIELD_, "Dodaj nowe pole");
define(_ADDFIELDINFO_, "W przypadku utworzenia nowego pola w bazie prosze wpisac nazwe ponizej a wybrac atrybuty SQL.co mo�na uczynic ponizej");
define(_FIELDNAME_, "Nazwa pola");
define(_FIELDTYPE_, "Typ pola");
define(_VALUE_, "Wartosc");
define(_FUNC_, "fukcja");

define(_TINYINT_, "Tiny integer");
define(_SMALLINT_, "maly integer");
define(_MEDIUMINT_, "sredni integer");
define(_INT_, "Integer");
define(_BIGINT_, "Dusy integer");
define(_FLOAT_, "Float");
define(_DOUBLE_, "Double");
define(_DECIMAL_, "Decimal");
define(_CHAR_, "Char");
define(_VARCHAR_, "Varchar");
define(_TINYTEXT_, "Tiny text");
define(_TINYBLOB_, "Tiny blob");
define(_ENUM_, "Enum");
define(_TEXT_, "Tekst");
define(_BLOB_, "Blob");
define(_MEDIUMTEXT_, "sredni tekst");
define(_MEDIUMBLOB_, "sredni blob");
define(_LONGTEXT_, "dlugi tekst");
define(_LONGBLOB_, "dlugi blob");
define(_DATETIME_, "Data &amp; Czas");
define(_DATE_, "Data");
define(_TIME_, "Czas");
define(_YEAR_, "Rok");
define(_TIMESTAMP_, "znacznik czasu");

define(_MODIFIERS_, "Modyfikacja");
define(_OK_, "OK");

define(_CREATEKEYERROR_, "Wystapi� b�ad podczas tworzenia nowego klucza");
define(_CREATEKEYGOOD_, "Klucz zosta� utworzony");
define(_ADDKEY_, "Dodaj nowy klucz");
define(_ADDKEYTOTABLE_, "Dodaj nowy klucz do tabeli");
define(_ADDKEYINFO_, "Aby utworzyc nowy klucz musisz wypelnic nastepujace pola: nazwa klucza wartosc klucza i te wartosci musza sie pokrywac.");
define(_ADDKEYWARNING_, "<u>UWAGA:</u>Pamietaj klucz nie moze przekraczac dlugosci 255 znakow!");
define(_KEYNAME_, "Nazwa klucza");
define(_KEYTYPE_, "Typ klucza");
define(_PRIMARYKEY_, "Klucz podstawowy");
define(_UNIQUEKEY_, "Niepowtarzalny klucz");
define(_NORMALKEY_, "Klucz");
define(_KEYFIELDS_, "Pola do pokrycia");
define(_FIELDS_, "Pola");

define(_ADDRECORDERROR_, "Nie mozna dodac wpisu");
define(_ADDRECORDGOOD_, "Dodano wpis do tabeli");
define(_LISTFIELDSERROR_, "nie mozna wyci�gnac listy p�l");
define(_ADDRECORD_, "Dodaj wpis");

define(_EXPORTTABLE_, "Eksportuj tabele");
define(_EXECUTESQL_, "Wykonaj polecenie SQL");

define(_CREATETABLE_, "Stworz nowa tabele");
define(_CREATETABLEINFO_, "Aby stworzyc tabele po prostu wpisz jej nazwe ponizej. Tabela zostanie utworzona z pustym polem o nazwie \"delete_me\", Z tego wzgledu i� wszystkie tabele potrzebuj� conajmniej jedna kolumne aby mogly istniec.");
define(_NEWTABLENAME_, "Nowa nazwa tabeli");
define(_DELETEDBERROR_, "Nie mozna skasowa� bazy");
define(_DROPFIELDERROR_, "Nie mozna usun�c pola");
define(_DROPFIELDGOOD_, "Pole usuniete");
define(_DROPKEYERROR_, "Nie mozna usun�c pola");
define(_DROPKEYGOOD_, "Klucz usuniety z powodzeniem");
define(_DELETERECORDERROR_, "blad nie mozna usun�c wpisu");
define(_DELETERECORDGOOD_, "Wpis usuniety");
define(_DROPTABLEERROR_, "nie mozna usunac tabeli");
define(_DROPTABLEGOOD_, "Tabela usunieta");
define(_CHOOSEEXPORT_, "wybierz co chcesz eksportowac");
define(_EXPORTINGDATA_, "Eksportowane materialy");
define(_CONSTRUCTION_, "Konstrukcja");
define(_TABLEDATA_, "eksportowane dane");
define(_TABLEKEYS_, "Klucze tabeli");
define(_EDITFIELDERROR_, "Nie mozna edytowac typu pola");
define(_EDITFIELDGOOD_, "Typ pola wyedytowany");
define(_EDITFIELD_, "edytuj typ pola");
define(_NEWFIELDTYPE_, "Nowy typ pola");

define(_ERROR_, "wystapil b��d");
define(_ERRORINFO_, "przykro mi ale wystapil blad podczas wykonywania tej operacji, jezeli wydaje ci sie ze blad wystabil z mojej winy prosze poinformuj mnie o tym <a href=\"mailto: bugs@mattsscripts.co.uk\">tutaj</a> opisujac co sie stalo. W innym przypadku po protu sie <a href=jacascript:hsitory.back()>cofnij</a>");
define(_ERRORMSG_, "Blad");

define(_ERRORDBCONNECT_, "Nie mozna sie polaczyc z serwerem prosze sprawdz login i has�o.");
define(_ERRORDBLIST_, "Nie mozna pobrac listy baz danych umieszczonych na serwerze, prosze skontaktuj sie adminem serwera po informacje.");

define(_HELPPAGE_, "Strona pomocy");
define(_HELPINTRO_, "\"Panel kontrolny Matta Willsona\" (MPanel) zostal napisany przez Matta Wilsona aby umozliwic uzytkownikom obslug� bazy mysqla poprzez przegladarke www zamiast polaczenia via telnet, lecz tak�e dla ludzi ktorzy pragneliby obslugiwac baze danych lecz nie znaja odpowiednich komend.");
define(_HELPCREATEDELETETABLE_, "Tworzenie/usuwanie tabel");
define(_HELPDELETEDB_, "Kasowanie bazy");
define(_INTRO_, "Wst�p");
define(_HELPADDDELETEFIELDS_, "Dodawanie i usuwanie pol z bazy");
define(_HELPALTERFIELDS_, "zmiana wlasciwosci pol/tabel w bazie");
define(_HELPINSERTRECORDS_, "Wpisywanie danych do tabel");
define(_HELPDELETERECORDS_, "kasowanie wpis�w z tabeli");
define(_HELPMODIFYRECORDS_, "Modyfikacje istniejacych juz tabel");
define(_HELPEXECUTESQL_, "Wykonwyanie polece� Mysqla");
define(_ETC_, "etc");

define(_HELPTOC_, "Zawarto��");
define(_HELPLOGIN_, "Logowanie do systemu");
define(_HELPCREATETABLE_, "Tworzenie tabeli");
define(_HELPADDFIELD_, "Dodanie pola do tabeli");
define(_HELPEDITFIELD_, "Edycja typu pola");
define(_HELPINSERTRECORD_, "dodanie wpisu do tabeli");
define(_HELPQUERYTABLE_, "Zapytanie tabeli o inforamcje");
define(_HELPDELETEMODIFYRECORD_, "Dodawanie/usuwanie wpisu w tabeli");
define(_HELPDELETEFIELD_, "Usuwanie pola w tabeli");
define(_HELPDELETETABLE_, "Usuniecie tabeli w bazie");
define(_HELPDELETEDB_, "Usuniecie bazy");
define(_HELPEXECUTINGSQL_, "wykonanie polecenia Mysql");
define(_HELPEXPORTING_, "exportowanie tabeli z bazy");
define(_HELPIMPORTING_, "Importowanie twojej wlasnej bazy");

define(_HELPLOGININFO_, "OK. To jest pierwsza najwazniesza cze�� z kt�ra si� musisz zapozna� inaczej twoje d��enia sko�cz� si� fiaskiem! Tw�j login to login za pomoc� kt�rego ��czysz si� z MySQL i has�o tak samo. W ten sam spos�b wybierasz baz� na kt�rej chcesz pracowa� w wypadku braku wyboru pojawi si� lista z kt�rej mo�esz wybra� baz�. Ostatnia cze�� to host na kt�rej znajduje si� twoja baza. Wa�ne jest tak�e ze niekt�re serwery nie pozwalaj� na po��czenia typu remote");
define(_HELPCREATETABLEINFO_, "Tworzenie baz danych tym skryptem jest bardzo latwe. Raz zalogowany klikni na stworzenie bazy. Wszystko masz wyjasnione kazda operacja jest poprzedzona wytlumaczeniem co sprawia i� twen skrypt jest bardzo latwy w obsludze aby dowiedziec si� ajk kasowac pola kliknij<a href=\"help.html#delfield\">tutaj</a>.");
define(_HELPADDFIELDINFO_, "Jezeli chcesz dodac ole do bazy musisz wybrac pozadana tabele poprzeze zalogowanie si� do niej i aby dodac pole musisz kliknac przycisk dodaj tabele. To spowoduje wyskoczenie okana popup z zapytaniem o nazwe tabeli i typ etc. Aby przeczytrac wiecej na ten temat zapraszam na strone <a target=_new href=\"http://www.mysql.com/documentation/index.html\">MySQL manual</a> lub na <a href=\"http://www.your-name-here.co.uk/mysql/fields.html\" target=_new>t� strone</a>");
define(_HELPEDITFIELDINFO_, "Edycja informacji w danych pola wymaga juz podstawowej znajomosci MySQLa I dlatego tez zapraszam na strone www.mysql.com aby sie zapoznac z instrukcj�");
define(_HELPINSERTRECORDINFO_, "To insert a record into one of your tables you must first select it on the main screen, this will take you to a page containing a list of all the fields in the table and some information on each of their types. By then clicking on the \"Add Record\" button you will be taken to another page containing an input dialog for each field where you can enter information in which will be placed into the record you wish to inser into the table. Once you have finished click \"Add Record\" at the bottom of the screen to insert the record into the database.o insert a record into one of your tables you must first select it on the main screen, this will take you to a page containing a list of all the fields in the table and some information on each of their types. By then clicking on the \"Add Record\" button you will be taken to another page containing an input dialog for each field where you can enter information in which will be placed into the record you wish to inser into the table. Once you have finished click \"Add Record\" at the bottom of the screen to insert the record into the database.");
define(_HELPQUERYTABLEINFO_, "one for each field in your table. This is where you put in the data that you want to search for, the script will then search the current database and table for the records matching the data your provided and will display the results in tables.");
define(_HELPDELETEMODIFYRECORDINFO_, "Tuaj zaczynaja sie klopoty gdyz majac dwa wpisy jednakowe w tabeli, gdy usuwasz jeden automatycznie usuwasz drugi. Mozesz jednak tego uniknac stosujac klucze dopasowane do kazdego wpisu i tabeli wiec pamietj przeczytaj na ten temat najpierw faq ze strony www.mysql.com a pozniej sie tym baw");
define(_HELPDELETEFIELDINFO_, "Usuwanie pol w tabeli wyglada tak samo jak usuwanie samych tabel ale pamietaj skrytp zapyta cie dla twojego bezpieczenstwa 3 razy czy jestes pewien ze chcesz usunac tabele ze by nie wyniknely pozniej z tego powodu klopoty.");
define(_HELPDELETETABLEINFO_, "Aby usunac tabele z bazy danych musisz tylk okliknac usun obok tabeli lecz pamietaj ze po usunieciu tabeli nie bedziesz mial mozliwosci odzyskania tych inforamcji wiec lepiej sie zastanow 3 razy zanim cos usuniesz.");
define(_HELPDELETEDBINFO_, "Aby usun�c baze musisz tylko kliknac na guzik usun tabele i program wykona wszystko za ciebie!");
define(_HELPEXECUTINGSQLINFO_, "Aby wykonac jakakolwiek komende Msqyl oczywiscie musisz wiedziec czym te komendy s� gdy� ten program wykonuj wszystkie komendy po cichu i mozesz nawet nie wiedziec kiedy cos sie zespuje w twojej bazie.");
define(_HELPEXPORTINGINFO_, "Exportowanie zawartosci jest tak samo proste jak importowanie gdyz musisz tylko kliknac guzik exportuj i wybierasz dane ktore maja zostac wyeksportowane.");
define(_HELPIMPORTINGINFO_, "Import bazy danych jest tym skryptewm bardzo prosty gdyz tylko musisz kliknac guzik import i zaimportowac wybrany przez ciebie plik. potem musisz odswiezyc okno i zawartosc sie ukaze na pulpicie.");

define(_IMPORTDATA_, "Importuj dane");
define(_IMPORTDATAINSTRUCT_, "aby zaimportowac jakiekolwiek dane do abzy musisz kliknac na przycisk \"Browse...\" i wybierz plik do zaimportowania.");
define(_IMPORTFILE_, "Importuj plik");
define(_IMPORTDBDATA_, "Importuj dane z bazy");

define(_WELCOMETITLE_, "Witaj");
define(_EXPORTDB_, "Eksportuj baze");
define(_DELETEDB_, "Usun baze");
define(_DELETETABLE_, "Usun tabele");
define(_OPTIMIZETABLE_, "Optymalizuj tabele");
define(_DELETEFIELD_, "Usu� pole");
define(_DELETEDBCONFIRM_, "Jestes pewien ze chcesz usunac ta baz�?");
define(_DELETEFIELDCONFIRM_, "Jestes pewein ze chcesz usun�� pole?");
define(_DELETETABLECONFIRM_, "Jestes pewein ze chcesz usun�� tabele?");
define(_LOGOUTCONFIRM_, "Chcesz sie wylogowac?");
define(_LOGOUT_, "Wyloguj");
define(_TABLENAME_, "Nazwa tabeli");
define(_COMMANDS_, "Komendy");
define(_KEYMANAGEMENT_, "Obsluga kluczy");

define(_DELETEKEYCONFIRM_, "Jestes pewien ze chcesz usuna� klucz?");
define(_DELETEKEY_, "Usun klucz");
define(_MODIFYARECORD_, "Modyfikuj wpis");

define(_LOGINERROR_, "nie mozesz sie zalogowac");
define(_LOGINERRORINFO_, "Przykro nam ale nie mozesz sie zalogowac, moze byc wiele powodow dla ktorych baza cie nie chce wposcic po prostu sprobuj jeszcze raz a jak b�ad sie bedzie powtarzal skotaktuj sie z adminem.");

define(_SEARCHRESULTS_, "Wyniki poszukiwania");
define(_FOUNDRECORDS_, "Znalazl nastepujace wpisy");
define(_NOPRIMARYKEY_, "brak podstawowego klucza lub unikalnego moze spowodowac bledy podczas wyszukiwania!");
define(_DELETERECORDCONFIRM_, "Chcesz usun�c ten wpis?");
define(_DELETERECORD_, "Usu� wpis");
define(_MODIFYRECORD_, "Modyfikuj wpis");
define(_SEARCHEMPTY_, "Nie znaleziono nic co by spe�nia�o twoje kryteria");
define(_RENAMEFIELD_, "Zmien nazwe pola");
define(_FIELDNEWNAME_, "Noa nazwa dla pola");
define(_FIELDNEWNAMEINFO_, "Prosze wprowadz nowe pole i kliknij ok.");

define(_RENAMETABLE_, "Zmien nazwe tabeli");
define(_TABLENEWNAME_, "Nowa nazwa dla tabeli");
define(_TABLENEWNAMEINFO_, "Prosze wprowadz now� tabele i kliknij ok");
define(_SQLRESULTS_, "resultaty SQL");
define(_SQLEXECUTED_, "komenda SQL wykonana");
define(_SQLOUTPUT_, "tutaj jest wyjscie komendy");
define(_SQLERROR_, "nie mozna wykonac komendy");

define(_SQLRESULTCODE_, "Zapytanie wykonane wynik jest nastepuj�cy");
define(_SQLRESULTROWS_, "liczba rzedow zwroconych");
define(_SQLRESULTROWSAFFECTED_, "liczba rzedow zwrocona");
define(_SQLRESULTFIELDS_, "liczba pol zwroconych");
define(_TABLEDETAILS_, "detale tabeli");
define(_ADDNEWFIELD_, "dodaj nowe pole");
define(_SEARCHDELETEMODIFYRECORDS_, "szukaj/dodaj/modyfikuj wpisy");

define(_CURDATABASE_, "biezaca baza");
define(_CURTABLE_, "bie�aca tabela");
define(_CHANGEFIELDTYPE_, "zmiana typu pola");
define(_SUCCESSMOD_, "Wpis zmodyfikowany z powodzeniem");
define(_ERRORMOD_, "blad podczas modyfikacji");
define(_ERRORMODRECORD_, "blad znajdz pole do modyfikacji");
define(_ERROROPTIMIZE_, "blad podczas modyfikacji tabeli");
define(_SUCCESSOPTIMIZE_, "Zoptymalizowano tabele");
define(_ERRORTABLEDESC_, "Nie mozna wyciagn�c opisu tabeli");
define(_SEARCHRECORDS_, "wyszukane wpisy");
define(_OPERATION_, "Operacje");
define(_TYPE_, "Typ");
define(_ERRORENAMEFIELD_, "Nie mozna zmienic nazwy pola");
define(_SUCCESSRENAMEFIELD_, "Nazwa pola zmieniona");
define(_ERRORRENAMETABLE_, "nie mozna zmienic nazwy tabeli");
define(_SUCCESSRENAMETABLE_, "zmieniono nazwe tabeli");
define(_RESET_, "Kasuj");

define(_AUTO_INCREMENT_FM_, "Auto Increment (All Int types)");
define(_BINARY_FM_, "Binary (Char, Varchar)");
define(_NOT_NULL_FM_, "Not NULL (All types)");
define(_UNSIGNED_FM_, "Unsigned (Numeric types)");
define(_ZERO_FILL_FM_, "Zero Fill (Numeric types)");
define(_DEFAULT_FM_, "Default (All, except BLOB, TEXT)");
define(_MODIFIERS_, "Modifiers");

define(_IMPORTSUCCESS_, "Dane zaimportowane z powodzeniem");

define(_UPDATE_, "aktualizuj");
define(_BROWSE_, "przegl�daj");
define(_EXPORTFMT_, "format eksportu");
define(_CHANGEDB_, "Zmien baze");
define(_CHANGETABLE_, "Zmien tabele");

define(_SHOWPAGE_, "pokaz nr strony");
define(_RESULTSPERPAGE_, "nr wynik�w pro strona");
define(_NEXTPAGE_, "Nastepna strona");
define(_PREVIOUSPAGE_, "Poprzednia strona");
define(_NOTE_, "Nota");

define(_ADDFIELDAFTER_, "dodaj pole po");
define(_TABLEEND_, "koniec tabeli");

define(_FINDDB_, "Znajdz baze");

define(_DBMANAGER_, "MAnadzer baz danych");
define(_ALLOWEDDBS_, "twoj uzytkownik ma dostep do nastepuj�cych baz danych");
define(_DISALLOWEDDBS_, "Istnieja bazy do ktorych nei masz dostepu");
define(_WELCOMEDB_, "Witaj na stronie administracyjnej. Mozesz zarzadac swoja tabel� w ramach uzyskanych pozwolen.");
define(_CREATEDB_, "Stworz baze");
define(_CREATEDBERROR_, "Nie mozna stworzyc bazy");
define(_CREATEDBGOOD_, "Stworzono baze danych");
define(_DELETEDBERROR_, "nie mozna usunac bazy");
define(_DELETEDBGOOD_, "Usunieto baze danych");
define(_GRANTDBERROR_, "nie mozna zmienic zezwolen uzytkownika");
define(_GRANTDBGOOD_, "Zmieniono pozwolenia uzytkownika");

define(_GRANTUSER_, "Zmien dostep uzytkownika do bazy");

define(_IMPORTTYPE_, "Format importowanego pliku");
define(_CSVHEADER_, "plik CSV zawiera w swoim header pola");
define(_CSVCONTAINER_, "pole CSV  container");
define(_CSVSEPERATOR_, "pole CSV  seperator");

//define(_SELECTDB_, "Please select the database you wish to administer");
//define(_DBLISTINFO_, "Underneath there are is a list of all the databases residing on the MySQL database server provided. Please click on the database that you wish to administrate.");

define(_BROWSEQUICK_, "Szybkie przegl�danie");

?>
